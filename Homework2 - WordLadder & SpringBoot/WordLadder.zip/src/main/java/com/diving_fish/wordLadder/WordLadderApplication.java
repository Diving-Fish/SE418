package com.diving_fish.wordLadder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WordLadderApplication {

    public static void main(String[] args) {
        SpringApplication.run(WordLadderApplication.class, args);
    }

}
