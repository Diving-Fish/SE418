# Redo WordLadder with SpringBoot

### Run:
```
mvn spring-boot:run
```

### Example:
```
localhost:8080/generate?start="code"&end="data"
localhost:8080/in_dict?word="dictionary"
```

### Test:

```
mvn test
```